## Packages
date-fns | Formatting dates for the dashboard
framer-motion | Animations for list items and page transitions
lucide-react | Icons for the dashboard interface

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
}
